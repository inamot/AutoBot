package net.sf.jabref.logic.autocompleter;


public enum AutoCompleteFirstNameMode {
    ONLY_FULL,
    ONLY_ABBREVIATED,
    BOTH
}
