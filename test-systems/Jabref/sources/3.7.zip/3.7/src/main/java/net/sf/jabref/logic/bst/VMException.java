package net.sf.jabref.logic.bst;

public class VMException extends RuntimeException {

    public VMException(String string) {
        super(string);
    }

}
