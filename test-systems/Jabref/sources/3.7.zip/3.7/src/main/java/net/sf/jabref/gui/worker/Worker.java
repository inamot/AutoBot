package net.sf.jabref.gui.worker;

/**
 * Represents a task that is not to be executed on the GUI thread
 */
public interface Worker extends Runnable {
    // Nothing
}
