package net.sf.jabref.logic.bst;

@FunctionalInterface
public interface Warn {

    void warn(String s);
}
