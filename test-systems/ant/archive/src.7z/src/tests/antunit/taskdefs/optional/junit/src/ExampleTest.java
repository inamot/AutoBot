import junit.framework.TestCase;

public class ExampleTest extends TestCase {
    public void testHello() {
        System.out.println("Hello From Test");
    }
}
